#include <stdlib.h>
#include <stdio.h>

int lire_fichier(const char* nom_de_fichier);

int ecrire_fichier(const char* nom_de_fichier, const char* message);