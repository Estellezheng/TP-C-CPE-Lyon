// TP 5 - Exercice 1
// Liste de fichiers et repertoires dans un dossier

#ifndef REPERTOIRE_H
#define REPERTOIRE_H

// Fonction pour lire le contenu d'un répertoire
void lire_dossier(const char *nom_repertoire);

void lire_dossier_recursif(const char *nom_repertoire);

#endif
